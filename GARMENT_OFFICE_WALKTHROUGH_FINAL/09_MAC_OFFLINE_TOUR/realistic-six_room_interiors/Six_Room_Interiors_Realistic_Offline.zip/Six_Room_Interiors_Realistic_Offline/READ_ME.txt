OFFICE REALISTIC TOUR — OFFLINE

Extract the entire folder, then double-click Office_Realistic_Tour.html.
Keep the asset-pack files and renders folder beside it. No server is needed by the package.

People shown are illustrative.
Proposed interior visualization. Final dimensions and technical details subject to site verification.

This package uses local JavaScript packs and Blob-backed fetch responses, not oversized data URLs.
Licence notices and asset provenance are retained in the licenses folder.
Physical MacBook Firefox/Chrome/Safari performance requires separate validation; do not infer it from Linux software-GPU tests.
See the accompanying package QA for the browsers actually tested; direct opening on the target Mac remains unverified.
